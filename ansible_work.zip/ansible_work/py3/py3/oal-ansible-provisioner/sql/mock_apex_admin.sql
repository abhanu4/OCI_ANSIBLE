/*******************************************/
/* SQL SCRIPT TO MOCK UP APEX ADMIN SCHEMA */
/*******************************************/

BEGIN

  -- Create user if it doesn't already exist
  BEGIN
    EXECUTE IMMEDIATE 'CREATE USER MOCK_APEX_ADMIN IDENTIFIED BY MOCK_APEX_ADMIN';
  EXCEPTION WHEN OTHERS THEN
    null;
  END;

  -- Grants
  BEGIN
    EXECUTE IMMEDIATE 'GRANT CREATE PROCEDURE TO MOCK_APEX_ADMIN';
    EXECUTE IMMEDIATE 'GRANT CREATE TABLE TO MOCK_APEX_ADMIN';
    EXECUTE IMMEDIATE 'GRANT UNLIMITED TABLESPACE TO MOCK_APEX_ADMIN';
  EXCEPTION WHEN OTHERS THEN
    null;
  END;

  -- Mock workspace view
  BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE MOCK_APEX_ADMIN.APEX_WORKSPACE_APEX_USERS(USER_NAME VARCHAR2(255), WORKSPACE_NAME VARCHAR2(255), IS_ADMIN VARCHAR2(30),WORKSPACE_ID NUMBER)';
  EXCEPTION WHEN OTHERS THEN
    null;
  END;
  BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE MOCK_APEX_ADMIN.APEX_WORKSPACES(WORKSPACE_ID NUMBER, WORKSPACE VARCHAR2(255))';
  EXCEPTION WHEN OTHERS THEN
    null;
  END;
  -- Unique index
  BEGIN
    EXECUTE IMMEDIATE 'CREATE UNIQUE INDEX MOCK_APEX_ADMIN.APEX_WORKSPACES_U1 ON MOCK_APEX_ADMIN.APEX_WORKSPACES(WORKSPACE_ID)';
  EXCEPTION WHEN OTHERS THEN
    null;
  END;
  -- Lookup index
  BEGIN
    EXECUTE IMMEDIATE 'CREATE INDEX MOCK_APEX_ADMIN.APEX_WORKSPACES_N1 ON MOCK_APEX_ADMIN.APEX_WORKSPACES(WORKSPACE)';
  EXCEPTION WHEN OTHERS THEN
    null;
  END;

  -- Mock packages
  EXECUTE IMMEDIATE '
create or replace package mock_apex_admin.apex_instance_admin as
  procedure add_workspace
   (p_workspace_id       in number,
    p_workspace          in varchar2,
    p_primary_schema     in varchar2,
    p_additional_schemas in varchar2);
  procedure add_schema
   (p_workspace    in varchar2,
    p_schema       in varchar2);
end apex_instance_admin;';

  EXECUTE IMMEDIATE '
create or replace package body mock_apex_admin.apex_instance_admin as
  procedure add_workspace
   (p_workspace_id       in number,
    p_workspace          in varchar2,
    p_primary_schema     in varchar2,
    p_additional_schemas in varchar2) is
  begin
    null;
  end add_workspace;
  procedure add_schema
   (p_workspace    in varchar2,
    p_schema       in varchar2) is
  begin
    null;
  end add_schema;
end apex_instance_admin;';
  EXECUTE IMMEDIATE '
create or replace package mock_apex_admin.apex_util as
  function find_security_group_id
   (p_workspace in varchar2)
    return number;
  procedure set_security_group_id
    (p_security_group_id in number);
  procedure create_user
   (p_user_id                      in number   default null,
    p_user_name                    in varchar2,
    p_first_name                   in varchar2 default null,
    p_last_name                    in varchar2 default null,
    p_description                  in varchar2 default null,
    p_email_address                in varchar2 default null,
    p_web_password                 in varchar2,
    p_web_password_format          in varchar2 default ''CLEAR_TEXT'',
    p_group_ids                    in varchar2 default null,
    p_developer_privs              in varchar2 default null,
    p_default_schema               in varchar2 default null,
    p_default_date_format          in varchar2 default null,
    p_allow_access_to_schemas      in varchar2 default null,
    p_account_expiry               in date     default trunc(sysdate),
    p_account_locked               in varchar2 default ''N'',
    p_failed_access_attempts       in number   default 0,
    p_change_password_on_first_use in varchar2 default ''Y'',
    p_first_password_use_occurred  in varchar2 default ''N'',
    p_attribute_01                 in varchar2 default null,
    p_attribute_02                 in varchar2 default null,
    p_attribute_03                 in varchar2 default null,
    p_attribute_04                 in varchar2 default null,
    p_attribute_05                 in varchar2 default null,
    p_attribute_06                 in varchar2 default null,
    p_attribute_07                 in varchar2 default null,
    p_attribute_08                 in varchar2 default null,
    p_attribute_09                 in varchar2 default null,
    p_attribute_10                 in varchar2 default null,
    p_allow_app_building_yn        in varchar2 default null,
    p_allow_sql_workshop_yn        in varchar2 default null,
    p_allow_websheet_dev_yn        in varchar2 default null,
    p_allow_team_development_yn    in varchar2 default null);
  procedure fetch_user 
   (p_user_id       in number,
    p_workspace     out varchar2,
    p_user_name     out varchar2,
    p_first_name    out varchar2,
    p_last_name     out varchar2,
    p_web_password  out varchar2,
    p_email_address out varchar2,
    p_start_date    out varchar2,
    p_end_date      out varchar2,
    p_employee_id   out varchar2,
    p_allow_access_to_schemas out varchar2,
    p_person_type     out varchar2,
    p_default_schema  out varchar2,
    p_groups          out varchar2,
    p_developer_role  out varchar2,
    p_description     out varchar2);
  procedure edit_user
   (p_user_id                      in number,
    p_user_name                    in varchar2,
    p_first_name                   in varchar2 default null,
    p_last_name                    in varchar2 default null,
    p_web_password                 in varchar2 default null,
    p_new_password                 in varchar2 default null,
    p_email_address                in varchar2 default null,
    p_start_date                   in varchar2 default null,
    p_end_date                     in varchar2 default null,
    p_employee_id                  in varchar2 default null,
    p_allow_access_to_schemas      in varchar2 default null,
    p_person_type                  in varchar2 default null,
    p_default_schema               in varchar2 default null,
    p_default_date_format          in varchar2 default null,
    p_group_ids                    in varchar2 default null,
    p_developer_roles              in varchar2 default null,
    p_description                  in varchar2 default null,
    p_account_expiry               in date     default null,
    p_account_locked               in varchar2 default ''N'',
    p_failed_access_attempts       in number   default 0,
    p_change_password_on_first_use in varchar2 default ''Y'',
    p_first_password_use_occurred  in varchar2 default ''N'');
end apex_util;
';
  EXECUTE IMMEDIATE '
create or replace package body mock_apex_admin.apex_util as
  function find_security_group_id
   (p_workspace in varchar2)
    return number is
  begin
    return 0;
  end find_security_group_id;
  procedure set_security_group_id
    (p_security_group_id in number) is
  begin
    null;
  end set_security_group_id;
  procedure create_user
   (p_user_id                      in number   default null,
    p_user_name                    in varchar2,
    p_first_name                   in varchar2 default null,
    p_last_name                    in varchar2 default null,
    p_description                  in varchar2 default null,
    p_email_address                in varchar2 default null,
    p_web_password                 in varchar2,
    p_web_password_format          in varchar2 default ''CLEAR_TEXT'',
    p_group_ids                    in varchar2 default null,
    p_developer_privs              in varchar2 default null,
    p_default_schema               in varchar2 default null,
    p_default_date_format          in varchar2 default null,
    p_allow_access_to_schemas      in varchar2 default null,
    p_account_expiry               in date     default trunc(sysdate),
    p_account_locked               in varchar2 default ''N'',
    p_failed_access_attempts       in number   default 0,
    p_change_password_on_first_use in varchar2 default ''Y'',
    p_first_password_use_occurred  in varchar2 default ''N'',
    p_attribute_01                 in varchar2 default null,
    p_attribute_02                 in varchar2 default null,
    p_attribute_03                 in varchar2 default null,
    p_attribute_04                 in varchar2 default null,
    p_attribute_05                 in varchar2 default null,
    p_attribute_06                 in varchar2 default null,
    p_attribute_07                 in varchar2 default null,
    p_attribute_08                 in varchar2 default null,
    p_attribute_09                 in varchar2 default null,
    p_attribute_10                 in varchar2 default null,
    p_allow_app_building_yn        in varchar2 default null,
    p_allow_sql_workshop_yn        in varchar2 default null,
    p_allow_websheet_dev_yn        in varchar2 default null,
    p_allow_team_development_yn    in varchar2 default null) is
  begin
    null;
  end create_user;
  procedure fetch_user 
   (p_user_id       in number,
    p_workspace     out varchar2,
    p_user_name     out varchar2,
    p_first_name    out varchar2,
    p_last_name     out varchar2,
    p_web_password  out varchar2,
    p_email_address out varchar2,
    p_start_date    out varchar2,
    p_end_date      out varchar2,
    p_employee_id   out varchar2,
    p_allow_access_to_schemas out varchar2,
    p_person_type     out varchar2,
    p_default_schema  out varchar2,
    p_groups          out varchar2,
    p_developer_role  out varchar2,
    p_description     out varchar2) is
  begin
    null;
  end fetch_user;
  procedure edit_user
   (p_user_id                      in number,
    p_user_name                    in varchar2,
    p_first_name                   in varchar2 default null,
    p_last_name                    in varchar2 default null,
    p_web_password                 in varchar2 default null,
    p_new_password                 in varchar2 default null,
    p_email_address                in varchar2 default null,
    p_start_date                   in varchar2 default null,
    p_end_date                     in varchar2 default null,
    p_employee_id                  in varchar2 default null,
    p_allow_access_to_schemas      in varchar2 default null,
    p_person_type                  in varchar2 default null,
    p_default_schema               in varchar2 default null,
    p_default_date_format          in varchar2 default null,
    p_group_ids                    in varchar2 default null,
    p_developer_roles              in varchar2 default null,
    p_description                  in varchar2 default null,
    p_account_expiry               in date     default null,
    p_account_locked               in varchar2 default ''N'',
    p_failed_access_attempts       in number   default 0,
    p_change_password_on_first_use in varchar2 default ''Y'',
    p_first_password_use_occurred  in varchar2 default ''N'') is
  begin
    null;
  end edit_user;

end apex_util;';

  EXECUTE IMMEDIATE 'GRANT EXECUTE ON mock_apex_admin.apex_instance_admin TO APEX_ADMINISTRATOR_ROLE';
  EXECUTE IMMEDIATE 'GRANT EXECUTE ON mock_apex_admin.apex_util TO APEX_ADMINISTRATOR_ROLE';
  EXECUTE IMMEDIATE 'GRANT SELECT  ON mock_apex_admin.apex_workspaces TO APEX_ADMINISTRATOR_ROLE';
  EXECUTE IMMEDIATE 'GRANT SELECT  ON mock_apex_admin.apex_workspace_apex_users TO APEX_ADMINISTRATOR_ROLE';

END;
