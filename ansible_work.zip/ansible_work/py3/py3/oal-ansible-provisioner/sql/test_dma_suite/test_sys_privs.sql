DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify OALPROV role includes the required SYS privs
  SELECT count(*) INTO l_count
  FROM
   (SELECT grantee, privilege, admin_option
    FROM
     (SELECT 'ROLE_OAL_DMA_ACCESS_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_ACCESS_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_ACCESS_SYSPRIVS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_DATA_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_DATA_SYSPRIVS' grantee, 'CREATE SEQUENCE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_DATA_SYSPRIVS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_DATA_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_DATA_SYSPRIVS' grantee, 'CREATE TABLE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_RUNTIME_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_RUNTIME_SYSPRIVS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_VIEWS_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_VIEWS_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_VIEWS_SYSPRIVS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DMA_VIEWS_SYSPRIVS' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL)
    MINUS
    SELECT grantee, privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee in
     ('ROLE_OAL_DMA_ACCESS_SYSPRIVS',
      'ROLE_OAL_DMA_DATA_SYSPRIVS',
      'ROLE_OAL_DMA_RUNTIME_SYSPRIVS',
      'ROLE_OAL_DMA_VIEWS_SYSPRIVS'));
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'At least one ROLE_OAL_DMA_%_SYSPRIVS role is missing a required system privilege');
  END IF;
  -- Verify TEST APP USER has the direct privs granted
  SELECT count(*) INTO l_count
  FROM
   (SELECT grantee, privilege, admin_option
    FROM
     (SELECT 'DMA_TEST$_APP1_RUNTIME' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_DATA' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_DATA' grantee, 'CREATE SEQUENCE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_DATA' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_DATA' grantee, 'CREATE TABLE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_VIEWS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_VIEWS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'DMA_TEST$_APP1_VIEWS' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL)
    MINUS
    SELECT grantee, privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee in
     ('DMA_TEST$_APP1',
      'DMA_TEST$_APP1_DATA',
      'DMA_TEST$_APP1_RUNTIME',
      'DMA_TEST$_APP1_VIEWS'));
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'At least one DMA_TEST$_APP1 schema is missing a direct system privilege');
  END IF;

END;
