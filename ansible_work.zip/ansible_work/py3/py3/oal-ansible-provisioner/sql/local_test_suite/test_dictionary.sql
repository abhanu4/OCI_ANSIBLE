DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify OAL dictionary role includes the required SYS privs
  SELECT count(*) INTO l_count
  FROM
   (SELECT table_name
    FROM
     (SELECT 'DBA_BASE_TABLE_MVIEWS' table_name FROM dual UNION ALL
      SELECT 'DBA_COL_COMMENTS' table_name FROM dual UNION ALL
      SELECT 'DBA_CONSTRAINTS' table_name FROM dual UNION ALL
      SELECT 'DBA_CONS_COLUMNS' table_name FROM dual UNION ALL
      SELECT 'DBA_ERRORS' table_name FROM dual UNION ALL
      SELECT 'DBA_INDEXES' table_name FROM dual UNION ALL
      SELECT 'DBA_IND_COLUMNS' table_name FROM dual UNION ALL
      SELECT 'DBA_IND_PARTITIONS' table_name FROM dual UNION ALL
      SELECT 'DBA_IND_SUBPARTITIONS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEWS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_COMMENTS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_DETAIL_PARTITION' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_DETAIL_RELATIONS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_DETAIL_SUBPARTITION' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_JOINS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_KEYS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_LOGS' table_name FROM dual UNION ALL
      SELECT 'DBA_MVIEW_LOG_FILTER_COLS' table_name FROM dual UNION ALL
      SELECT 'DBA_OBJECTS' table_name FROM dual UNION ALL
      SELECT 'DBA_PART_KEY_COLUMNS' table_name FROM dual UNION ALL
      SELECT 'DBA_PART_TABLES' table_name FROM dual UNION ALL
      SELECT 'DBA_ROLES' table_name FROM dual UNION ALL
      SELECT 'DBA_ROLE_PRIVS' table_name FROM dual UNION ALL
      SELECT 'DBA_SUBPARTITION_TEMPLATES' table_name FROM dual UNION ALL
      SELECT 'DBA_SUBPART_KEY_COLUMNS' table_name FROM dual UNION ALL
      SELECT 'DBA_SYNONYMS' table_name FROM dual UNION ALL
      SELECT 'DBA_TABLES' table_name FROM dual UNION ALL
      SELECT 'DBA_TAB_COLS' table_name FROM dual UNION ALL
      SELECT 'DBA_TAB_COMMENTS' table_name FROM dual UNION ALL
      SELECT 'DBA_TAB_PARTITIONS' table_name FROM dual UNION ALL
      SELECT 'DBA_TAB_PRIVS' table_name FROM dual UNION ALL
      SELECT 'DBA_TAB_SUBPARTITIONS' table_name FROM dual UNION ALL
      SELECT 'DBA_VIEWS' table_name FROM dual UNION ALL
      SELECT 'ROLE_ROLE_PRIVS' table_name FROM dual)
    MINUS
    SELECT table_name
    FROM dba_tab_privs
    WHERE grantee = 'ROLE_OAL_DATA_DICTIONARY'
    AND privilege = 'SELECT');
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Role ROLE_OAL_DATA_DICTIONARY is missing a required system privilege');
  END IF;

END;
