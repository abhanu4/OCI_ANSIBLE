DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify OALPROV has OALPROV role
  SELECT count(*) INTO l_count
  FROM dba_role_privs
  WHERE grantee = 'OALPROV'
  AND granted_role = 'ROLE_OAL_OALPROV';
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'User OALPROV is missing ROLE_OAL_OALPROV role');
  END IF;

  -- Verify OALPROV role has the required ROLES
  SELECT count(*) INTO l_count
  FROM
   (SELECT granted_role, admin_option
    FROM
     (SELECT 'JAVAUSERPRIV' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_BIA_RUNTIME_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DATA_DICTIONARY' granted_role, 'NO' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_ACCESS_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_VIEWS_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DMA_ACCESS_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DMA_DATA_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DMA_RUNTIME_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_DMA_VIEWS_SYSPRIVS' granted_role, 'YES' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_OALMON_DICTIONARY' granted_role, 'NO' admin_option FROM dual UNION ALL
      SELECT 'ROLE_OAL_OALPROV_DICTIONARY' granted_role, 'NO' admin_option FROM dual)
    MINUS
    SELECT granted_role, admin_option
    FROM ROLE_ROLE_PRIVS
    WHERE role = 'ROLE_OAL_OALPROV');
  -- Error if any of the roles is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Role ROLE_OAL_OALPROV is missing a required role grant');
  END IF;

END;
