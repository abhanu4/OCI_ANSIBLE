DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify OALPROV role includes the required SYS privs
  SELECT count(*) INTO l_count
  FROM
   (SELECT privilege, admin_option
    FROM
     (SELECT 'ALTER TABLESPACE' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'ALTER USER' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE ANY DIRECTORY' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE DATABASE LINK' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE MATERIALIZED VIEW' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE PROCEDURE' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE ROLE' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE SEQUENCE' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE SESSION' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE SYNONYM' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE TABLE' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE TABLESPACE' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE USER' privilege, 'NO' admin_option FROM dual UNION ALL
      SELECT 'CREATE VIEW' privilege, 'NO' admin_option FROM dual)
    MINUS
    SELECT privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee = 'ROLE_OAL_OALPROV'
    MINUS
    SELECT privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee IN
     (SELECT rrp.granted_role
      FROM role_role_privs rrp
      CONNECT BY PRIOR rrp.role = rrp.granted_role
      START with rrp.role in
       (SELECT x.granted_role
        FROM dba_role_privs x
        WHERE x.grantee = 'OALPROV'
        AND x.granted_role LIKE 'ROLE_OAL%')));
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Role ROLE_OAL_OALPROV is missing a required system privilege');
  END IF;

END;
