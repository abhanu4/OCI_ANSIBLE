DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test app has export dir
  SELECT count(*) INTO l_count
  FROM DBA_DIRECTORIES 
  WHERE DIRECTORY_NAME = 'TEST$_APP1_EXP_DIR';
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Export directory Name=TEST$_APP1_EXP_DIR does not exist.');
  END IF;
END;
