DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test app has import dir
  SELECT count(*) INTO l_count
  FROM DBA_DIRECTORIES 
  WHERE DIRECTORY_NAME = 'TEST$_APP1_IMP_DIR';
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Import directory Name=TEST$_APP1_IMP_DIR does not exist.');
  END IF;
END;
