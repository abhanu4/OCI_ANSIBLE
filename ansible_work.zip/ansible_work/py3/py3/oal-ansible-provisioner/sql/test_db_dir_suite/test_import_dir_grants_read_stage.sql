DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test app has export dir
  SELECT count(*) INTO l_count
  FROM DBA_TAB_PRIVS
  WHERE TABLE_NAME = 'TEST$_APP1_IMP_DIR'
    AND GRANTEE = 'TEST$_APP1_STAGE'
    AND PRIVILEGE = 'READ'
  ;
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'TEST$_APP1_STAGE is missing READ privilege on directory Name=TEST$_APP1_IMP_DIR.');
  END IF;
END;
