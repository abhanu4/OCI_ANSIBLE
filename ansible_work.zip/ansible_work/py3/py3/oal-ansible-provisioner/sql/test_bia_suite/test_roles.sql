DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test app schemas have the correct roles granted
  SELECT count(*) INTO l_count
  FROM dba_role_privs
  WHERE (grantee, granted_role) IN 
   (('BIA_TEST$_APP1_RUNTIME',      'ROLE_OAL_BIA_RUNTIME_SYSPRIVS'));
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'One or more test app schemas is missing the ROLE_OAL_DIA_%_SYSPRIVS role');
  END IF;

END;
