DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify OALPROV role includes the required SYS privs
  SELECT count(*) INTO l_count
  FROM
   (SELECT grantee, privilege, admin_option
    FROM
     (SELECT 'ROLE_OAL_BIA_RUNTIME_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL)
    MINUS
    SELECT grantee, privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee in
     ('ROLE_OAL_BIA_RUNTIME_SYSPRIVS'));
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'At least one ROLE_OAL_BIA_%_SYSPRIVS role is missing a required system privilege');
  END IF;

END;
