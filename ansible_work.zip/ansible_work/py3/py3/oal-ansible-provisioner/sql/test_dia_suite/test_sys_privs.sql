DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify OALPROV role includes the required SYS privs
  SELECT count(*) INTO l_count
  FROM
   (SELECT grantee, privilege, admin_option
    FROM
     (SELECT 'ROLE_OAL_DIA_ACCESS_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_ACCESS_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_ACCESS_SYSPRIVS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE DATABASE LINK' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE MATERIALIZED VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE SEQUENCE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE TABLE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE DATABASE LINK' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE MATERIALIZED VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE SEQUENCE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE TABLE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_VIEWS_SYSPRIVS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_VIEWS_SYSPRIVS' grantee, 'CREATE SESSION' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'ROLE_OAL_DIA_VIEWS_SYSPRIVS' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL)
    MINUS
    SELECT grantee, privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee in
     ('ROLE_OAL_DIA_ACCESS_SYSPRIVS',
      'ROLE_OAL_DIA_DATA_SYSPRIVS',
      'ROLE_OAL_DIA_STAGE_SYSPRIVS',
      'ROLE_OAL_DIA_VIEWS_SYSPRIVS'));
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'At least one ROLE_OAL_DIA_%_SYSPRIVS role is missing a required system privilege');
  END IF;
  -- Verify TEST APP USER has the direct privs granted
  SELECT count(*) INTO l_count
  FROM
   (SELECT grantee, privilege, admin_option
    FROM
     (SELECT 'TEST$_APP1' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_DATA' grantee, 'CREATE MATERIALIZED VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_DATA' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_DATA' grantee, 'CREATE SEQUENCE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_DATA' grantee, 'CREATE SYNONYM' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_DATA' grantee, 'CREATE TABLE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_DATA' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_STAGE' grantee, 'CREATE MATERIALIZED VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_STAGE' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_STAGE' grantee, 'CREATE SEQUENCE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_STAGE' grantee, 'CREATE TABLE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_STAGE' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_VIEWS' grantee, 'CREATE PROCEDURE' privilege, 'NO' admin_option
      FROM DUAL UNION ALL
      SELECT 'TEST$_APP1_VIEWS' grantee, 'CREATE VIEW' privilege, 'NO' admin_option
      FROM DUAL)
    MINUS
    SELECT grantee, privilege, admin_option
    FROM dba_sys_privs
    WHERE grantee in
     ('TEST$_APP1',
      'TEST$_APP1_DATA',
      'TEST$_APP1_STAGE',
      'TEST$_APP1_VIEWS'));
  -- Error if any of the SYS privs is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'At least one TEST$_APP1 schema is missing a direct system privilege');
  END IF;

END;
