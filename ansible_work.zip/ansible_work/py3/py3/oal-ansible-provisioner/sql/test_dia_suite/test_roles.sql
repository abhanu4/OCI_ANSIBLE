DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test app schemas have the correct roles granted
  SELECT count(*) INTO l_count
  FROM dba_role_privs
  WHERE (grantee, granted_role) IN 
   (('TEST$_APP1',      'ROLE_OAL_DIA_ACCESS_SYSPRIVS'),
    ('TEST$_APP1_DATA', 'ROLE_OAL_DIA_DATA_SYSPRIVS'),
    ('TEST$_APP1_STAGE','ROLE_OAL_DIA_STAGE_SYSPRIVS'),
    ('TEST$_APP1_VIEWS','ROLE_OAL_DIA_VIEWS_SYSPRIVS'));
  -- Error if role not found
  IF (l_count <> 4) THEN
    RAISE_APPLICATION_ERROR(-20001, 'One or more test app schemas is missing the ROLE_OAL_DIA_%_SYSPRIVS role');
  END IF;

  -- Verify test app schemas have the correct sys privs granted
  SELECT count(*) INTO l_count
  FROM
   (SELECT role, granted_role, admin_option
    FROM
     (SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' role, 'JAVAUSERPRIV' granted_role, 'NO' admin_option
      FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_STAGE_SYSPRIVS' role, 'ROLE_OAL_DATA_DICTIONARY' granted_role, 'NO' admin_option
      FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' role, 'JAVAUSERPRIV' granted_role, 'NO' admin_option
      FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_ACCESS_SYSPRIVS' role, 'ROLE_OAL_DATA_DICTIONARY' granted_role, 'NO' admin_option
      FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_DATA_SYSPRIVS' role, 'ROLE_OAL_DATA_DICTIONARY' granted_role, 'NO' admin_option
      FROM dual UNION ALL
      SELECT 'ROLE_OAL_DIA_VIEWS_SYSPRIVS' role, 'ROLE_OAL_DATA_DICTIONARY' granted_role, 'NO' admin_option
      FROM dual)
    MINUS
    SELECT role, granted_role, admin_option
    FROM ROLE_ROLE_PRIVS
    WHERE role in
     ('ROLE_OAL_DIA_ACCESS_SYSPRIVS',
      'ROLE_OAL_DIA_DATA_SYSPRIVS',
      'ROLE_OAL_DIA_STAGE_SYSPRIVS',
      'ROLE_OAL_DIA_VIEWS_SYSPRIVS'));
  -- Error if any of the roles is not granted
  IF (l_count <> 0) THEN
    RAISE_APPLICATION_ERROR(-20001, 'One or more test app roles are missing a required role grant');
  END IF;

END;
