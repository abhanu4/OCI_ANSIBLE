DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test app roles are granted correctly to the group devops roles
  SELECT count(*) INTO l_count
  FROM dba_role_privs
  WHERE grantee like 'ROLE_APG_TEST$__DEVOPS_RSTR';
--
-- Expected results:
--
-- select granted_role || ' to ' || grantee
-- From dba_role_privs
-- where grantee like 'ROLE_APG_TEST$__DEVOPS_RSTR'
-- order by 1;
--
-- ROLE_APG_TEST$2_DEVOPS_RSTR to ROLE_APG_TEST$1_DEVOPS_RSTR
-- ROLE_APG_TEST$3_DEVOPS_RSTR to ROLE_APG_TEST$1_DEVOPS_RSTR
-- ROLE_APG_TEST$4_DEVOPS_RSTR to ROLE_APG_TEST$2_DEVOPS_RSTR
-- ROLE_APG_TEST$5_DEVOPS_RSTR to ROLE_APG_TEST$2_DEVOPS_RSTR
-- ROLE_TEST$_APP1_DEVOPS_RSTR to ROLE_APG_TEST$4_DEVOPS_RSTR
-- ROLE_TEST$_APP2_DEVOPS_RSTR to ROLE_APG_TEST$2_DEVOPS_RSTR
-- ROLE_TEST$_APP3_ALL_INTL to ROLE_APG_TEST$2_DEVOPS_RSTR
-- ROLE_TEST$_APP3_ALL_RSTR to ROLE_APG_TEST$2_DEVOPS_RSTR
--
  -- Error if grant not found
  IF (l_count <> 8) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Got '||to_char(l_count)||' app group devops grants, expecting 8');
  END IF;
  -- Verify test app group roles are granted correctly
  SELECT count(*) INTO l_count
  FROM dba_role_privs
  WHERE grantee like 'ROLE_APG_TEST$__RSTR';
--
-- Expected results:
--
-- select granted_role || ' to ' || grantee
-- From dba_role_privs
-- where grantee like 'ROLE_APG_TEST$__RSTR'
-- order by 1;
--
-- ROLE_APG_TEST$1_INTL to ROLE_APG_TEST$1_RSTR
-- ROLE_APG_TEST$2_INTL to ROLE_APG_TEST$2_RSTR
-- ROLE_APG_TEST$2_RSTR to ROLE_APG_TEST$1_RSTR
-- ROLE_APG_TEST$3_INTL to ROLE_APG_TEST$3_RSTR
-- ROLE_APG_TEST$3_RSTR to ROLE_APG_TEST$1_RSTR
-- ROLE_APG_TEST$4_INTL to ROLE_APG_TEST$4_RSTR
-- ROLE_APG_TEST$4_RSTR to ROLE_APG_TEST$2_RSTR
-- ROLE_APG_TEST$5_INTL to ROLE_APG_TEST$5_RSTR
-- ROLE_APG_TEST$5_RSTR to ROLE_APG_TEST$2_RSTR
-- ROLE_TEST$_APP1_CDM_RSTR to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_REVN_RSTR to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_REV_INTL to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_REV_RSTR to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_SALES_INTL to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_SCM_INTL to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_SCM_OM_INTL to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP1_SCM_QP_INTL to ROLE_APG_TEST$4_RSTR
-- ROLE_TEST$_APP2_ALL_RSTR to ROLE_APG_TEST$2_RSTR
-- ROLE_TEST$_APP2_REV_RSTR to ROLE_APG_TEST$2_RSTR
-- ROLE_TEST$_APP2_RSTR to ROLE_APG_TEST$2_RSTR
--
  -- Error if role not found
  IF (l_count <> 20) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Got '||to_char(l_count)||' app group role grants, expecting 20');
  END IF;
END;
