DECLARE
  l_count  NUMBER;
  l_role_count NUMBER := 24;
BEGIN
  -- Verify test app roles are granted to correct recipients
  SELECT count(*) INTO l_count
  FROM dba_role_privs
  WHERE (granted_role, grantee) IN 
   (('ROLE_TEST$_APP1_CDM_RSTR','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_MONITOR','ROLE_OAL_OALMON'),
    ('ROLE_TEST$_APP1_MONITOR','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_PUBLIC','PUBLIC'),
    ('ROLE_TEST$_APP1_REVN_RSTR','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_REVN_RSTR','ROLE_TEST$_APP1_REVN_HIRS'),
    ('ROLE_TEST$_APP1_REV_INTL','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_REV_INTL','ROLE_TEST$_APP1_REV_HIRS'),
    ('ROLE_TEST$_APP1_REV_INTL','ROLE_TEST$_APP1_REV_RSTR'),
    ('ROLE_TEST$_APP1_REV_RSTR','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_REV_RSTR','ROLE_TEST$_APP1_REV_HIRS'),
    ('ROLE_TEST$_APP1_SALES_INTL','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_SCM_INTL','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_SCM_INTL','ROLE_TEST$_APP1_SCM_OM_INTL'),
    ('ROLE_TEST$_APP1_SCM_INTL','ROLE_TEST$_APP1_SCM_QP_INTL'),
    ('ROLE_TEST$_APP1_SCM_OM_INTL','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP1_SCM_QP_INTL','ROLE_TEST$_APP1_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP2_ALL_RSTR','ROLE_TEST$_APP2_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP2_MONITOR','ROLE_TEST$_APP2_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP2_MONITOR','ROLE_OAL_OALMON'),
    ('ROLE_TEST$_APP2_PUBLIC','PUBLIC'),
    ('ROLE_TEST$_APP2_REV_RSTR','ROLE_TEST$_APP2_DEVOPS_RSTR'),
    ('ROLE_TEST$_APP2_RSTR','ROLE_TEST$_APP2_ALL_RSTR'),
    ('ROLE_TEST$_APP2_RSTR','ROLE_TEST$_APP2_DEVOPS_RSTR'));
  -- Error if role not found
  IF (l_count <> l_role_count) THEN
    RAISE_APPLICATION_ERROR(-20001, 'One or more test app role grants is missing');
  END IF;

  -- Verify no extras
  SELECT count(*) INTO l_count
  FROM
   (SELECT 1
    FROM dba_role_privs
    WHERE granted_role like 'ROLE_TEST$_APP1%'
    -- Exclude OALPROV and any application group roll-ups
    AND grantee <> 'OALPROV'
    AND grantee not like 'ROLE_APG%'
    UNION ALL
    SELECT 1
    FROM dba_role_privs
    WHERE granted_role like 'ROLE_TEST$_APP2%'
    -- Exclude OALPROV and any application group roll-ups
    AND grantee <> 'OALPROV'
    AND grantee not like 'ROLE_APG%');
  -- Error if any of the roles is not granted
  IF (l_count <> l_role_count) THEN
    RAISE_APPLICATION_ERROR(-20001, 'One or more test app roles is granted extra to expectations');
  END IF;

END;
