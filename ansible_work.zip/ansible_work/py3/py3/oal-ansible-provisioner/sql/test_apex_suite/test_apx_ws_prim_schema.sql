DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test workspace was created
  SELECT count(*) INTO l_count
  FROM apex_workspace_schemas
  WHERE WORKSPACE_NAME = 'TSTAPP1'
        AND FIRST_SCHEMA_PROVISIONED = 'OAL_APX_DEFAULT'
        AND SCHEMA = 'OAL_APX_DEFAULT';
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Incorrect primary schema=OAL_APX_DEFAULT for workspace Name=TSTAPP1');
  END IF;
END;
