DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test workspace has correct schemas
  SELECT count(*) INTO l_count
  FROM apex_workspace_schemas
  WHERE WORKSPACE_NAME = 'TSTAPP1'
        --AND SCHEMA IN ('DMA_TSTAPP1_DATA','DMA_TSTAPP1_RUNTIME','DMA_TSTAPP1_VIEWS');
        AND SCHEMA IN ('OAL_APX_DEFAULT','DMA_TSTAPP1_DATA');
  -- Error if role not found
  IF (l_count <> 2) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Incorrect schemas for workspace Name=TSTAPP1');
  END IF;
END;
