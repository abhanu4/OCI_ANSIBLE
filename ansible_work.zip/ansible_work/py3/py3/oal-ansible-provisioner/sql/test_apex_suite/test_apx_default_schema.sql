DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify default apex schema exists
  SELECT count(*) INTO l_count
  FROM dba_users
  WHERE username = 'OAL_APX_DEFAULT';
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'APEX default schema=OAL_APX_DEFAULT does not exist');
  END IF;
END;
