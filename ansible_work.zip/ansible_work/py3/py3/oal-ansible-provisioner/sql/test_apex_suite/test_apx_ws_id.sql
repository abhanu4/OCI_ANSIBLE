DECLARE
  l_ws_id  NUMBER;
BEGIN
  -- Verify test workspace was created
  SELECT workspace_id INTO l_ws_id
  FROM apex_workspaces
  WHERE WORKSPACE = 'TSTAPP1';
  -- Error if role not found
  IF (l_ws_id <> 100001) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Workspace Name=TSTAPP1 has invalid workspace_id');
  END IF;
END;
