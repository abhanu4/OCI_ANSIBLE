DECLARE
  l_count  NUMBER;
BEGIN
  -- Verify test workspace was created
  SELECT count(*) INTO l_count
  FROM apex_workspaces
  WHERE WORKSPACE = 'TSTAPP1';
  -- Error if role not found
  IF (l_count <> 1) THEN
    RAISE_APPLICATION_ERROR(-20001, 'Workspace Name=TSTAPP1 Does not exist');
  END IF;
END;
