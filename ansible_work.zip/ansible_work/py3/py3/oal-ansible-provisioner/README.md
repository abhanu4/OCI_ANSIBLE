oal-ansible-provisioner.git 

## OVERVIEW
_This project is still under construction.  It is usable, but evolving._ 11/13/2018  todd.grimmett@oracle.com  

- This project contains the python modules, ansible playbooks and tools comprising the OAL BI IAC provisioner.  
- It uses standard Ansible components and directory structures with some modifications.  
- The OS user 'ansible' is the owner and operator of the provisioning files and mechanisms, **ALWAYS RUN AS USER 'ansible' UNLESS OTHERWISE DIRECTED**  
- The OS group 'ansible' can be used as well, but results may vary.
- The term 'model' as used in the document means the collection of YAML var files that define how we want a particular Data Platform Application structured.  
- There are custom python programs (/etc/ansible/library/oracle_oal\*) that use the standard ansible packages to extend ansible for use by OAL for provisioning BI objects.  

## REVISION HISTORY
11/13/2018 Todd Grimmett Initial setup  
11/14/2018 Todd Grimmett Add task in create_oal_sys_roles.yml to create the OS subdirectory for a tablespace.  
11/15/2018 Todd Grimmett Modify OS mkdir step in create_oal_sys_roles.yml to use ssh key and passphrase   
11/16/2018 Todd Grimmett Move remote login credential from ansible hosts file to var files.  
11/17/2018 Todd Grimmett Suppress passwords in the spool and action files  
11/21/2018 Todd Grimmett A create_oal_dia_platform.yml and supporting artifacts  
11/26/2018 Todd Grimmett Add task for create roles and supporting files to playbook   
12/11/2018 Todd Grimmett Add BI App playbook and supporting artifacts  
12/13/2018 Todd Grimmett Add Data Management App playbook and supporting artifacts  
12/21/2018 Todd Grimmett Add APEX playbook and supporting artifacts  
12/31/2018 Todd Grimmett Break out var file types it individual dirs and update installer accordingly.  
01/02/2019 Todd Grimmett Modify cron job run_create_dpa_playbook.py to use broken out var file dires.  
01/02/2019 Todd Grimmett Modify oracle_oal_dia_platform to use write_action()   
01/02/2019 Todd Grimmett Modify oracle_oal_bia_platform to use write_action()   
01/07/2019 Todd Grimmett Modify oracle_oal_dma_platform to use write_action()   
01/16/2019 Todd Grimmett Add artifacts for creating the Data Platform Application Report.  
03/14/2019 Todd Grimmett Add artifacts for creating the ODI Repository databaes roles and users.   
05/22/2019 Todd Grimmett Update files for creating database directories  
09/04/2019 Todd Grimmett Add Application Group support for DIA apps.  
10/14/2019 Todd Grimmett Add Drift Tester (DIA only).  
11/20/2019 Todd Grimmett Add files for creating the OALFND_SYSPRIV_REQUEST_PKG package that grants a named user proxy access to a data platform application    
02/24/2020 Todd Grimmett Add files for creating first Application Directory table (DPA_DATA_PLATFORM_APPL)    
03/06/2020 Troy Mancinelli Add support for creating flattener and proxy in sys provisioner - OALCDP-3942, OALCDP-3943, OALCDP-3944  
05/27/2020 Todd Grimmett OALCDP-5364 Modify provisioner to make modifications to the app catalog tables.  
06/11/2020 Todd Grimmett Add CREATE VIEW ability to app cat maintainer.  
06/16/2020 Troy Mancinelli Adding v_env_cat_host and v_env_cat_db  
06/26/2020 Todd Grimmett Add show_run_summary.py as first step of OALCDP-6068.    
06/29/2020 Todd Grimmett Add show_installed.py  and show_actions.py as next step of OALCDP-6068.    

## NOTES
1. __Longterm password managment is yet to be figured out. Until then all passwords are in Ansible Vault encrypted files.  Ansible has the functionality to decrypt these files at runtime without exposing their contents.__  
2. **The first task in create_oal_sys_roles.yml playbook creates the subdirectory needed for SHARED_T_S_01 tablespace.  The technique employed will do a ssh to the database host as root and prompt for the password, no SSH keys are used.  We could use a different technique to use SSH keys, but I chose this way to keep it simple and follow the pattern of SYS where a password is prompted for.**
3. If you run create_oal_dia_platform.yml playbook by passing in the vars_oalprov_usr.yml var file, the playbook will run in mode=normal  
4. If you run create_oal_dia_platform.yml playbook by passing in the vars_(user_name)_sys_usr.yml var file, the playbook will run in mode=sysdba and prompt for appropriate passwords  


## DEPENDANCIES
- This project is dependant on ansible being installed.
- This project is dependant on the python cx_Oracle package being installed.  cx_Oracle is used to provide pythong with connectivity to Oracle databases.
- ansible/cx_Oracle installation can be done via [https://alm.oraclecorp.com/oal/#projects/iac/scm/oal-ansible-with-oracle-modules-provisioning.git/tree/?revision=master](https://alm.oraclecorp.com/oal/#projects/iac/scm/oal-ansible-with-oracle-modules-provisioning.git/tree/?revision=master)
- The above git project will also install the base oracle modules, but these are not needed for OAL BI provisioning.  The base modules (oracle*) have been supersceded by custom (oracle_oal*) modules. 

## INSTALLATION

Step 1. Do a git clone or git pull of this project.  
Step 2. From the project directory above, run: _install.py_  

## TO RUN THE 'SYS' BOOTSTRAP PLAYBOOK
This example uses the "local" environment, but can substitute "local" with the target environment
Step 1. Modify these variables in /etc/ansible/envs/local/dpa_vars/vars_local_db_db.yml to point to your 'local' database:   
&nbsp;&nbsp;&nbsp;&nbsp;v_hostname  
&nbsp;&nbsp;&nbsp;&nbsp;v_service_name  
&nbsp;&nbsp;&nbsp;&nbsp;v_port  
&nbsp;&nbsp;&nbsp;&nbsp;v_df_path (* this is the filesystem path where datafiles will be created *)  
Step 2. Modify the ansible_host variable in /etc/ansible/hosts file LOCALDB_HOST entry with your correct host/IP (ansible_host)     
Step 3. Modify /etc/ansible/envs/local/dpa_vars/vars_tgrimmet_sys_usr.yml with correct v_remote_os_user and v_ssh_key_file values.  The name of this file may be changed, just make sure to specify the correct var file name in the 'ansible-playbook' call  
&nbsp;&nbsp;&nbsp;&nbsp; NOTE: _the ansible_user must be able to sudo to root on the db server_  
Step 4. Put your ssh key file in the place specified in v_ssh_key_file parameter above, the standard directory is /etc/ansible/envs/<env_name>/ssh  
### Calling the playbook directly
Step 5. cd to /etc/ansible/playbooks  
Step 6. run the playbook to create the system roles and OALPROV user:  
&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv create_oal_sys_roles.yml --ask-pass -c paramiko -e @/etc/ansible/envs/common/vars_sys/vars_sys_roles_sys.yml -e @/etc/ansible/envs/local/vars_tablespace/vars_SHARED_T_S_01_tbs.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_user/vars_tgrimmet_sys_usr.yml_

create_oal_sys_roles.yml will prompt for the SSH and SYS passwords.

### Using the sys playbook script
Step 5. cd to /etc/ansible/bin
Step 6. ./run_sys_playbook.sh local tgrimmet

## TO RUN ALL THE APPLICATION PLAYBOOKS
Pre-requisites:
1. All variable files for the environment and users have been setup

For e.g. local environment:
1. Change directory to /etc/ansible/bin
2. ./run_create_dpa_playbook.sh --env local

## TO RUN THE DATA INTEGRATION PLATFORM CREATE PLAYBOOK AGAINST A 'local' DATABASE  
&nbsp;&nbsp;&nbsp;&nbsp;NOTE: Setting up the environment variables in the 'SYS' bootstrap  step above needs to be completed.  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/dpa_vars/vars_oalprov_usr.yml to match your environment  
Step 2. run the playbook to create the SDS_GEC Data Integration Platform database objects.  
&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv create_oal_dia_platform.yml -e @/etc/ansible/envs/local/vars_tablespace/vars_SDS_T_tbs.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_dpa/vars_sds_gec_dia_dpa.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml_  

Notes:  
1) var file naming convention of DIApps variables is vars_(DIApp_name)_dia_dpa.yml  

## TO RUN THE BUSINESS INTELLIGENCE (BI Runtime) PLATFORM CREATE PLAYBOOK AGAINST A 'local' DATABASE  
&nbsp;&nbsp;&nbsp;&nbsp;NOTE: Setting up the environment variables in the 'SYS' bootstrap  step above needs to be completed.  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/dpa_vars/vars_oalprov_usr.yml to match your environment  
Step 2. run the playbook to create the OALATG BI Runtime Platform database objects.  
&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv create_oal_bia_platform.yml -e @/etc/ansible/envs/local/vars_tablespace/vars_BI_T_tbs.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_dpa/vars_oalatg_bia_dpa.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml_

Notes:  
1) var file naming convention of BI Runtime variables is vars_(BIApp_name)_bia_dpa.yml  
2) Assuming SYS provisioner has only been ran for DIApps, you will need to re-run the SYS provisioner to pick up the ROLE_OAL_BIA_RUNTIME_SYSPRIVS role.  

## TO RUN THE DATA MANAGMENT PLATFORM CREATE PLAYBOOK AGAINST A 'local' DATABASE  
&nbsp;&nbsp;&nbsp;&nbsp;NOTE: Setting up the environment variables in the 'SYS' bootstrap  step above needs to be completed.  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/dpa_vars/vars_oalprov_usr.yml to match your environment  
Step 2. run the playbook to create the OALATG Data Managment Platform database objects.  
&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv create_oal_dma_platform.yml -e @/etc/ansible/envs/local/vars_tablespace/vars_SHARED_T_S_01_tbs.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_dpa/vars_cld_dma_dpa.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml_

## TO GENERATE A DATA PLATFORM APPLICATION REPORT AGAINST A 'local' DATABASE  
&nbsp;&nbsp;&nbsp;&nbsp;NOTE: Setting up the environment variables in the 'SYS' bootstrap step above needs to be completed.  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/dpa_vars/vars_oalprov_usr.yml to match your environment  
Step 2. run the playbook to create the OALATG Data Managment Platform database objects.  
&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv generate_dpa_report.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml_

Note: This report can be generated via cron by using the supplied script in bin/run_generate_dpa_report.sh  
&nbsp;&nbsp;&nbsp;&nbsp;SAMPLE crontab entry: 0  0  *  *  *  /etc/ansible/bin/run_generate_dpa_report.sh -env local > /etc/ansible/envs/local/logs/run_generate_dpa_report_local.log 2>&1  

## TO RUN THE CREATE APEX WORKSPACE PLAYBOOK AGAINST A 'local' DATABASE  
&nbsp;&nbsp;&nbsp;&nbsp;NOTE: Setting up the environment variables in the 'SYS' bootstrap  step above needs to be completed.  

__IMPORTANT:__ This playbook/module currently needs to connect as Apex schema owner or SYS, which wont pass a security review.  We are waiting on Shalabh to come back with implementation reequirements  
&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv create_oal_apex_workspace.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_apex/vars_apx_cld_dpa.yml -e @/etc/ansible/envs/local/vars_user/vars_apex_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_apex_pwd.yml_  

Notes:  
1) var file naming convention of Data Management Applicaion variables is vars_(DMApp_identifier)_dma_dpa.yml  
2) Assuming SYS provisioner has not been ran for DMApps, you will need to re-run the SYS provisioner to pick up the ROLE_OAL_DMA_*_SYSPRIVS roles.  

## TO RUN THE PLAYBOOK THAT CREATES THE SYS PACKAGE USED BY OIM TO GRANT A NAMED USER PROXY ACCESS TO A DATA PLATFORM APPLICATION AGAINST A 'local' DATABASE  

&nbsp;&nbsp;&nbsp;&nbsp;_/etc/ansible/envs/local/bin/run_sys_proxy_playbook.sh local tgrimmet_  

## TO RUN THE ODI REPOSITORY ROLES/SCHEMAS CREATE PLAYBOOK AGAINST A 'local' DATABASE  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/vars_user/vars_tgrimmet_sys_usr.yml (or whatever your file is) to match your environment  
Step 2. run the playbook to create the ODI Repository database objects.  

&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv /etc/ansible/playbooks/create_oal_odi_rep.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_user/vars_tgrimmet_sys_usr.yml -e @/etc/ansible/envs/local/vars_tablespace/vars_SHARED_T_S_01_tbs.yml -e @/etc/ansible/envs/common/vars_sys/vars_odi_roles_sys.yml_  

Notes:  
1) var file naming convention of var file containing the ODI Repository system roles is /etc/ansible/envs/common/vars_sys/vars_odi_roles_sys.yml  
2) /etc/ansible/envs/common/vars_sys/vars_odi_roles_sys.yml should contain just the roles, not users.  Users will be created via module oracle_oal_odi_repo_users.    
3) the variables associated to ODI Repository are in the environment var file.  In other words you 'assign' the ODI Repository database via the environment file you are using.  Example is /etc/ansible/envs/local/vars_env/vars_local_db_db.yml  

## REGARDING DATABASE DIRECTORIES
On 5/22/2019 a new version of playbook and module to create database directories was created.  The new version removed the java stored procedure and replaced it with steps in create_oal_dpa_dir.yml that use the ansible 'file' module to mkdir.  
The 'file' module must login to the db server as 'oaldistg' user.  

There is also a new version of the SYS provisioning playbook that makes ownership and permission changes to the /u0x/app_acfs directory from oracle:oinstall to oaldistg:oaldistg to accomadate these changes.  
SO RUN THE SYS provisioner before running the create_oal_dpa_dir.yml playbook. 

There are no steps in create_oal_dia_platform.yml to create database directories or their supporting OS directories.  This task is isolated to a seperate playbook.  
Calling create_oal_dpa_dir.yml is also not integrated into run_create_dpa_playbook.py, the cronjob.  That is a TODO if/when all parties decide to have the provisioner create directories. 

There is a switch to create the OS directories that support the DB directories, it defaults to FALSE  
  The switch is controlled by variable v_env_create_os_dir, which is intended to be in the environment .yml  
    v_env_create_os_dir: false  will NOT create the OS directoies, this is the default  
    v_env_create_os_dir: true   will create the OS directoies  

## TO RUN DATABASE DIRECTORY CREATE PLAYBOOK AGAINST A 'local' DATABASE  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml (or whatever your file is) to match your environment  
Step 2. Create or modify the vars_oaldistg_os_usr.yml variable value in /etc/ansible/envs/local/vars_user/vars_oaldistg_os_usr.yml to match your environment.  oaldistg user will need a passphrase-less ssh key for this to function correctly.  
Step 3. run the playbook 

&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv /etc/ansible/playbooks/create_oal_dpa_dir.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_dpa/vars_fdl_common_dia_dpa.yml -e @/etc/ansible/envs/local/vars_tablespace/vars_FDL_T_tbs.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml -e @/etc/ansible/envs/local/vars_user/vars_oaldistg_os_usr.yml_  

## TO RUN DRIFT TEST PLAYBOOK AGAINST A 'local' DATABASE  

Step 1. Modify the v_oalprov_pwd variable value in /etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml (or whatever your file is) to match your environment  
Step 2. run the playbook 

&nbsp;&nbsp;&nbsp;&nbsp;_ansible-playbook -vv /etc/ansible/env/local/playbooks/drift_test_oal_dia_platform.yml -e @/etc/ansible/envs/local/vars_env/vars_local_db_db.yml -e @/etc/ansible/envs/local/vars_dpa/vars_fdl_common_dia_dpa.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_usr.yml -e @/etc/ansible/envs/local/vars_user/vars_oalprov_pwd.yml 

## DRIFT TEST NOTES

1) script process_drift_files.sh calls process_drift_files.py that will run a drift test for all DIA apps.  If drift is detected and alert email will be sent by /scratch/tgrimmet/bin/pull_drift_test_alert.sh on slc14xyh.  
2) a drift_(DPApp).txt file will be maintained by drift_test_oal_dia_platform.yml for each app.  See this file for the current drift info as well as corrective SQL.  
3) process_drift_files.py will read the individual drift files in the spool directory and maintain a summary in /etc/ansible/envs/(env)/metrics/drift_summary.txt.  This file drives the drift detection.  

## APPENDIX
###Notes on encrypting password (or any other) file:

To encrypt a password file

1. echo 'some_password' > /etc/ansible/.vault_pwd
2. chmod 600 /etc/ansible/.vault_pwd
3. echo 'vault_password_file=/etc/ansible/.vault_pwd' >> ansible.cfg

create a var file with the sys pwd in it like:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cat vars_odipdb_db_pwd.yml  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;v_sys_pwd: some_pwd

encrypt the var file:

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ansible-vault encrypt vars_odipdb_db_pwd.yml

Alternative to using ansible.cfg are
+ environment variable: export ANSIBLE_VAULT_PASSWORD_FILE=/etc/ansible/.vault_password
+ pass "--vault-password-file pass-ansible.txt" on each ansible command.

###Notes on setting up ANSIBLE on the OCI Provisioning Server
130.35.49.132  (OCI provisioning server)

slc11zhm /scratch/sshtunnel_to_paas> ssh -R 8888:www-proxy-brmdc.us.oracle.com:80 -i oraclehq_ssh.ppk oraclehq@130.35.49.132  
[oraclehq@cdpansible ~]$ sudu su -  
[root@cdpansible ~]# export http_proxy=http://localhost:8888  
[root@cdpansible ~]# export https_proxy=http://localhost:8888  
[root@cdpansible ~]# yum install gcc  
[root@cdpansible ~]# yum install git  
[root@cdpansible ~]# yum install python-devel  
[root@cdpansible ~]# cd /u01  
[root@cdpansible u01]# cd oal  
[root@cdpansible oal]# mkdir cx_Oracle  
[root@cdpansible oal]# cd cx_Oracle  
[root@cdpansible cx_Oracle]# git clone https://github.com/oracle/python-cx_Oracle.git /u01/oal/cx_Oracle/cx_Oracle  
[root@cdpansible oal]# cd cx_Oracle  
[root@cdpansible cx_Oracle]# pwd  
/u01/oal/cx_Oracle/cx_Oracle  
[root@cdpansible cx_Oracle]# git submodule init  
[root@cdpansible cx_Oracle]# git submodule update  
[root@cdpansible cx_Oracle]# python setup.py install  
/* copied instant client and sqlplus rpms to cdpansible /u01/oal/ansible/oracle_client_18.3 from my laptop */  
[root@cdpansible oracle_client_18.3]# cd /u01/oal/ansible/oracle_client_18.3  
[root@cdpansible oracle_client_18.3]# yum install --assumeyes oracle-instantclient18.3-basic-18.3.0.0.0-3.x86_64.rpm  
[root@cdpansible oracle_client_18.3]# yum install --assumeyes oracle-instantclient18.3-sqlplus-18.3.0.0.0-3.x86_64.rpm  


###TO DOS:
1. Implement ODI Repository playbook into cronjob  
2. Implement create database directories into cronjob  
