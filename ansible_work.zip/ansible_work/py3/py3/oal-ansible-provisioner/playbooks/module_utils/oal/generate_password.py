def generate_password():
    import random

    #chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890^():;'
    chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890^:;'

    password = ''

    # Password length is 8 characters
    for c in range(8):
        password += random.choice(chars)

    # For ADW we need 12 chars including uppercase, lowercase, number and special
    password = 'aB2#'+password

    return password
