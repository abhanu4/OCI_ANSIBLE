#
# Modification History:
#   05/11/2020 jesus.asturiano@oracle.com  Module to populate DPA_GROUP as per OALCDP-5168
#
def populate_dpa_group_table(module, msg, cursor, spool, outfile, global_changed, facts, app_group_name, creating_file):
 
    import cx_Oracle
    #import datetime
 
    msg=['']
 
    #sysdate_time= datetime.datetime.now().date().strftime('%d-%b-%Y')
    sql = "INSERT INTO OALPROV.DPA_GROUP (DPA_GROUP_CODE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID) VALUES ('" + app_group_name + "','" + creating_file  + "',SYSTIMESTAMP,'" + creating_file + "',SYSDATE, NULL)"
        


    try:
            cursor.execute(sql)
            #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False
 
    return    