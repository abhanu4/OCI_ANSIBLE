#
# Modification History:
#   05/11/2020 jesus.asturiano@oracle.com  Checks to see if DPA_GROUP has existing data as per OALCDP-5168
#
def check_dpa_group_has_data(module, msg, cursor, spool, outfile, global_changed, facts, app_group_name):
 
    import cx_Oracle
    import datetime
 
    msg=['']

    sql = "SELECT COUNT(*) FROM OALPROV.DPA_GROUP WHERE DPA_GROUP_CODE = '" + app_group_name + "'"

    try:
            cursor.execute(sql)
            result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    if result > 0:
      return True
    else:
      return False