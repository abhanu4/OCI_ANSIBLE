#
# Modification History:
#   04/30/2020  javier.e.arias@oracle.com  Adding all snippets together in the same file for DPA table checks
#   05/14/2020  javier.e.arias@oracle.com  Adding new modules to fetch dates in DPA_DATA_PLATFORM_APPL and DPA_SCHEMA
#


# Snippet to find if specified record exists in DPA_DATA_PLATFORM_APPL
def check_dpa_app_record_exists(module, msg, cursor, spool, outfile, global_changed, facts, dpa_type, dpa_code):

    import cx_Oracle
    
    msg=['']
    
    sql = "SELECT COUNT(*) FROM OALPROV.DPA_DATA_PLATFORM_APPL WHERE DPA_TYPE = '" + dpa_type + "' AND DPA_CODE = '" + dpa_code + "'"
    
    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False
    
    if result > 0:
        return True
    else:
        return False



# Snippet to find if specified record exists in DPA_SCHEMA
def check_dpa_schema_record_exists(module, msg, cursor, spool, outfile, global_changed, facts, schema_name):

    import cx_Oracle

    msg=['']

    sql = "SELECT COUNT(*) FROM OALPROV.DPA_SCHEMA WHERE SCHEMA_NAME = '" + schema_name + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    if result > 0:
        return True
    else:
        return False



# Snippet to find if specified record exists in DPA_ROLES
def check_dpa_roles_record_exists(module, msg, cursor, spool, outfile, global_changed, facts, role_name):

    import cx_Oracle

    msg=['']

    sql = "SELECT COUNT(*) FROM OALPROV.DPA_ROLES WHERE ROLE_NAME = '" + role_name + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    if result > 0:
        return True
    else:
        return False



# Snippet to find if specified record exists in DPA_ROLE_GRANT_TO_ROLE
def check_dpa_role_grant_role_record_exists(module, msg, cursor, spool, outfile, global_changed, facts, granted_role, grantee_role):

    import cx_Oracle

    msg=['']

    sql = "SELECT COUNT(*) FROM OALPROV.DPA_ROLE_GRANT_TO_ROLE WHERE GRANTED_ROLE = '" + granted_role + "' AND GRANTEE_ROLE = '" + grantee_role + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    if result > 0:
        return True
    else:
        return False




# Snippet to find if specified record exists in DPA_ROLE_GRANT_TO_SCHEMA
def check_dpa_role_grant_schema_record_exists(module, msg, cursor, spool, outfile, global_changed, facts, role_name, schema_name):

    import cx_Oracle

    msg=['']

    sql = "SELECT COUNT(*) FROM OALPROV.DPA_ROLE_GRANT_TO_SCHEMA WHERE ROLE_NAME = '" + role_name + "' AND SCHEMA_NAME = '" + schema_name + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    if result > 0:
        return True
    else:
        return False



# Snippet to get date schema was created in DBA_USERS
def get_dba_users_create_date(module, msg, cursor, spool, outfile, global_changed, facts, schema):

    import cx_Oracle

    msg=['']

    sql = "SELECT TO_CHAR(CREATED, 'DD-MON-YYYY HH24:MI:SS') FROM DBA_USERS WHERE USERNAME = '" + schema + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return ''

    return result

# Snippet to get ROLE_TYPE value in DPA_ROLES
def get_dpa_role_type_value(module, msg, cursor, spool, outfile, global_changed, facts, role):

    import cx_Oracle

    msg=['']

    sql = "SELECT ROLE_TYPE FROM DPA_ROLES WHERE ROLE_NAME = '" + role + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return ''

    return result


# Snippet to get APT requested date from APT through BugDB
def get_apt_req_date(module, msg, cursor, spool, outfile, global_changed, facts, req_id):

    import cx_Oracle

    msg=['']

    sql = "SELECT RPTDATE FROM BUG.RPTHEAD WHERE RPTNO = '" + req_id + "'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return ''

    return result


# Snippet to get APT approved date from APT through BugDB
def get_apt_apprv_date(module, msg, cursor, spool, outfile, global_changed, facts, req_id):

    import cx_Oracle

    msg=['']

    sql = "SELECT MAX(UPD_DATE) FROM (SELECT UPD_DATE FROM BUG.RPTBODY WHERE RPTNO = '" + req_id + "' AND COMMENTS LIKE '%approved%')"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return ''

    return result


# Snippet to get APT provisioned date from APT through BugDB
def get_apt_prov_date(module, msg, cursor, spool, outfile, global_changed, facts, req_id):

    import cx_Oracle

    msg=['']

    sql = "SELECT UPD_DATE FROM BUG.RPTBODY WHERE RPTNO = '" + req_id + "' AND COMMENTS LIKE '%Provision%'"

    try:
        cursor.execute(sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return ''

    return result
