#
# Modification History:
#   04/08/2020 javier.e.arias@oracle.com  Module to populate DPA_ROLE_GRANT_TO_SCHEMA
#
def populate_dpa_role_grant_s_table(module, msg, cursor, spool, outfile, global_changed, facts, role_name, schema_name, dpa_request, source):
 
    import cx_Oracle
    #import datetime
 
    msg=['']
 
    #sysdate_time= datetime.datetime.now().date().strftime('%d-%b-%Y')
    sql = "INSERT INTO OALPROV.DPA_ROLE_GRANT_TO_SCHEMA (ROLE_NAME, SCHEMA_NAME, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID, PROVISIONED_DATE) VALUES ('" + role_name + "','" + schema_name + "','" + source + "',SYSTIMESTAMP,'" + source + "',SYSDATE,'" + dpa_request + "',NULL)"
 
    try:
            cursor.execute(sql)
            #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False
 
    return    
