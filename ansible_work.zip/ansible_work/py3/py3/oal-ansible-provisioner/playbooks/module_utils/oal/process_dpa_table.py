#
# Modification History:
#   06/30/2020  javier.e.arias@oracle.com  Initial definition
#


# Snippet to generically handle INSERT or UPDATE for a DPA table by just sending row information
# NOTE: Dates must be send to this method in datetime.datetime format
def process_dpa_table(module, msg, cursor, spool, outfile, global_changed, facts, owner, table, row):

    import cx_Oracle
    import datetime

    msg=['']

    # Checking that the row information sent contains at least the required unique key columns. If not we will have to exit right away as we cannot process anything
    unique_index_sql = "SELECT COLUMN_NAME FROM DBA_IND_COLUMNS WHERE INDEX_NAME = (SELECT INDEX_NAME FROM DBA_INDEXES WHERE UNIQUENESS = 'UNIQUE' AND TABLE_OWNER = '" + owner + "' AND TABLE_NAME = '" + table + "') AND TABLE_OWNER = '" + owner + "' AND TABLE_NAME = '" + table + "'"

    try:
        cursor.execute(unique_index_sql)
        result = cursor.fetchall()
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return "failure"

    unique_rows = result
    unique_keys = True

    for unique_key in unique_rows:
        if unique_key[0] not in row:
            unique_keys = False

    # If the unique key columns are not found then we need to quit right away
    if unique_keys is False:
        msg[0] = "At least one of the unique key colums for table " + table + " are missing from the row information sent to be processed. Perhaps there was a typo somewhere? Please check the appropriate name for the table's columns and try again\n"
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return "failure"

    # Now we need column information on the required table so we know how to formulate the following queries
    columns = []
    data_types = []
    cols = ""
    cols_sql = "SELECT COLUMN_NAME, DATA_TYPE FROM DBA_TAB_COLS WHERE OWNER = '" + owner + "' AND TABLE_NAME = '" + table + "' AND HIDDEN_COLUMN = 'NO' ORDER BY COLUMN_ID"

    try:
        cursor.execute(cols_sql)
        results = cursor.fetchall()
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + cols_sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return "failure"

    for res in results:
        columns.append(res[0])
        data_types.append(res[1])
        cols = cols + res[0] + ", "

    cols = cols.strip()[:-1]

    # Given the unique index, we need to check if the information sent already exists in the table. If it does, then this is and UPDATE operation, if it doesn't this is an INSERT operation

    # First let's figure out the WHERE clause which will be used for the UPDATE statement and fetching the current info in case it exists in the database
    where_clause = ""

    # Trying to tackle as many data types as possible
    for unique_key in unique_rows:
        if data_types[columns.index(unique_key[0])] == 'NUMBER' or 'BINARY' in data_types[columns.index(unique_key[0])]:
            where_clause = where_clause + unique_key[0] + " = " + row[unique_key[0]] + " AND "
        elif "CHAR" in data_types[columns.index(unique_key[0])] or "ROWID" in data_types[columns.index(unique_key[0])]:
            where_clause = where_clause + unique_key[0] + " = '" + row[unique_key[0]] + "' AND "
        elif "RAW" in data_types[columns.index(unique_key[0])]:
            where_clause = where_clause + unique_key[0] + " = HEXTORAW('" + row[unique_key[0]] + "') AND "
        elif "DATE" in data_types[columns.index(unique_key[0])]:
            if isinstance(row[unique_key[0]], str) and row[unique_key[0]] == "":
                where_clause = where_clause + unique_key[0] + " = NULL AND "
            else:
                where_clause = where_clause + unique_key[0] + " = TO_DATE('" + row[unique_key[0]].strftime("%d-%b-%Y %H:%M:%S").upper() + "', 'DD-MON-YYYY HH24:MI:SS') AND "
        elif "TIMESTAMP" in data_types[columns.index(unique_key[0])]:
            if isinstance(row[unique_key[0]], str) and row[unique_key[0]] == "":
                where_clause = where_clause + unique_key[0] + " = NULL AND "
            else:
                where_clause = where_clause + unique_key[0] + " = TO_TIMESTAMP('" + row[unique_key[0]].strftime("%d-%b-%Y %H:%M:%S.%f").upper() + "', 'DD-MON-YYYY HH24:MI:SS.FF') AND "
        else:
            where_clause = where_clause + unique_key[0] + " = TO_CHAR('" + row[unique_key[0]] + "') AND "

    where_clause = where_clause[:-4].strip()

    # Now se are going to check to see if the row already exists given the unique index columns we fetched before
    check_sql = "SELECT COUNT(*) FROM " + owner + "." + table + " WHERE " + where_clause

    try:
        cursor.execute(check_sql)
        result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + check_sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return "failure"

    if result > 0:
        # The record exists so it may need to be updated. We need to check if any of the data sent is different from the actual data. Only sent columns will be taken into account
        curr_row = {}
        values = []
        select_sql = "SELECT " + cols + " FROM " + owner + "." + table + " WHERE " + where_clause

        try:
            cursor.execute(select_sql)
            results = cursor.fetchall()[0]
        except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + select_sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return "failure"

        # Fetching the results and adding them to a dictionary so they are easy to compare to the sent row
        for y in range(len(results)):
            values.append(results[y])

        for x in range(len(columns)):
            curr_row[columns[x]] = values[x]

        # Checking if there are any differences between the data sent, and the current data in the database
        update_cols = []
        for key in row:
            if key in curr_row and key != "CREATION_DATE" and key != "CREATED_BY" and key != "LAST_UPDATED_BY" and key != "LAST_UPDATE_DATE":
                if row[key] is None:
                    row[key] = ""
                if curr_row[key] is None:
                    curr_row[key] = ""
                if row[key] != curr_row[key]:
                    update_cols.append(key)
                    
        # If there are differences, then we will run the update operation
        if len(update_cols) > 0:
            updates = ""
            for col in update_cols:
                if data_types[columns.index(col)] == 'NUMBER' or 'BINARY' in data_types[columns.index(col)]:
                    updates = updates + col + " = " + row[col] + ", "
                elif "CHAR" in data_types[columns.index(col)] or "ROWID" in data_types[columns.index(col)]:
                    updates = updates + col + " = '" + row[col] + "', "
                elif "RAW" in data_types[columns.index(col)]:
                    updates = updates + col + " = HEXTORAW('" + row[col] + "'), "
                elif "DATE" in data_types[columns.index(col)]:
                    if isinstance(row[col], str) and row[col] == "":
                        updates = updates + col + " = NULL, "
                    else:
                        updates = updates + col + " = TO_DATE('" + row[col].strftime("%d-%b-%Y %H:%M:%S").upper() + "', 'DD-MON-YYYY HH24:MI:SS'), "
                elif "TIMESTAMP" in data_types[columns.index(col)]:
                    if isinstance(row[col], str) and row[col] == "":
                        updates = updates + col + " = NULL, "
                    else:
                        updates = updates + col + " = TO_TIMESTAMP('" + row[col].strftime("%d-%b-%Y %H:%M:%S.%f").upper() + "', 'DD-MON-YYYY HH24:MI:SS.FF'), "
                else:
                    updates = updates + col + " = TO_CHAR('" + row[col] + "'), "

            if "LAST_UPDATED_BY" in curr_row:
                last_update_user = ""
                if "LAST_UPDATED_BY" in row:
                    last_update_user = row["LAST_UPDATED_BY"]
                    updates = updates + "LAST_UPDATED_BY = '" + last_update_user + "', "

            if "LAST_UPDATE_DATE" in curr_row:
                last_update_date = datetime.datetime.now()
                if "LAST_UPDATE_DATE" in row:
                    last_update_date = row["LAST_UPDATE_DATE"]
                    updates = updates + "LAST_UPDATE_DATE = TO_TIMESTAMP('" + last_update_date.strftime("%d-%b-%Y %H:%M:%S.%f").upper() + "', 'DD-MON-YYYY HH24:MI:SS.FF'), "
            updates = updates.strip()[:-1]

            update_sql = "UPDATE " + owner + "." + table + " SET " + updates + " WHERE " + where_clause

            try:
                cursor.execute(update_sql)
                global_changed = True
            except cx_Oracle.DatabaseError, exc:
                error, = exc.args
                msg[0] = error.message+' sql: ' + update_sql
                module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
                return "failure"

            return "changed"

        else:
            return "unchanged"

    else:
        # This is an INSERT, preparing SQL statement to add the new row
        insert_sql = "INSERT INTO " + owner + "." + table + " "
        cols = "("
        vals = "VALUES("

        for key in row:
            cols = cols + key + ","
            if row[key] is None or row[key] == "":
                vals = vals + "NULL,"
            else:
                if data_types[columns.index(key)] == 'NUMBER' or 'BINARY' in data_types[columns.index(key)]:
                    vals = vals + row[key] + ","
                elif "CHAR" in data_types[columns.index(key)] or "ROWID" in data_types[columns.index(key)]:
                    vals = vals + "'" + row[key] + "',"
                elif "RAW" in data_types[columns.index(key)]:
                    vals = vals + "HEXTORAW('" + row[key] + "'),"
                elif "DATE" in data_types[columns.index(key)]:
                    if isinstance(row[key], str) and row[key] == "":
                        vals = vals + "NULL,"
                    else:
                        vals = vals + "TO_DATE('" + row[key].strftime("%d-%b-%Y %H:%M:%S").upper() + "', 'DD-MON-YYYY HH24:MI:SS'),"
                elif "TIMESTAMP" in data_types[columns.index(key)]:
                    if isinstance(row[key], str) and row[key] == "":
                        vals = vals + "NULL,"
                    else:
                        vals = vals + "TO_TIMESTAMP('" + row[key].strftime("%d-%b-%Y %H:%M:%S.%f").upper() + "', 'DD-MON-YYYY HH24:MI:SS.FF'),"
                else:
                    vals = vals + "TO_CHAR('" + row[key] + "'),"

        cols = cols[:-1] + ") "
        vals = vals[:-1] + ")"

        insert_sql = insert_sql + cols + vals

        try:
            cursor.execute(insert_sql)
            global_changed = True
        except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + insert_sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

        return "changed"

