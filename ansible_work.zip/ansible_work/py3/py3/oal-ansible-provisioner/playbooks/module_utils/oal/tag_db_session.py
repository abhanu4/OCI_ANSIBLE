def tag_db_session(module, msg, cursor, module_name, action_name):
    import cx_Oracle

    msg = ['']

    sql = """
BEGIN
        dbms_application_info.set_module( module_name => '"""+module_name+"""', action_name => '"""+action_name+"""');
END;
"""

    try:
            cursor.execute(sql)
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' ERROR: tagging session sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    return True
