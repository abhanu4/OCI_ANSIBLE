#=================================================================================
#
# Function to write an action to the actionfile
#
def write_action(action, actfile, action_msg, action_sev, action_sql = ''):

    if action:
        actfile.write('--ACTION: '+action_sev+': '+action_msg+'\n')
        if action_sql:
            actfile.write(action_sql+';\n')
        actfile.write('\n')
        return True
    else:
        return False

    return False
