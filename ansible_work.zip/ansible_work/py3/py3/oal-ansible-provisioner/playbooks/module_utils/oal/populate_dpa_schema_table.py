#
# Modification History:
#   03/14/2020 javier.e.arias@oracle.com  Module to populate DPA_ROLES
#
def populate_dpa_schema_table(module, msg, cursor, spool, outfile, global_changed, facts, schema_name, dpa_type, dpa_code, dpa_request, creating_file):
 
    import cx_Oracle
    #import datetime
 
    msg=['']
 
    #sysdate_time= datetime.datetime.now().date().strftime('%d-%b-%Y')
    sql = "INSERT INTO OALPROV.DPA_SCHEMA (SCHEMA_NAME, DPA_TYPE, DPA_CODE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID, PROVISIONED_DATE) VALUES ('" + schema_name + "','" + dpa_type + "','" + dpa_code + "','" + creating_file  + "',SYSTIMESTAMP,'" + creating_file + "',SYSDATE,'" + dpa_request + "',NULL)"
 
    try:
            cursor.execute(sql)
            #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False
 
    return    
