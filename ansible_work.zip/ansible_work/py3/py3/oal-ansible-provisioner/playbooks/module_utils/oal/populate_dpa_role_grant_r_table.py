#
# Modification History:
#   04/20/2020 javier.e.arias@oracle.com  Module to populate DPA_ROLE_GRANT_TO_ROLE
#
def populate_dpa_role_grant_r_table(module, msg, cursor, spool, outfile, global_changed, facts, granted_role, grantee_role, dpa_request, source):
 
    import cx_Oracle
    #import datetime
 
    msg=['']
 
    #sysdate_time= datetime.datetime.now().date().strftime('%d-%b-%Y')
    sql = "INSERT INTO OALPROV.DPA_ROLE_GRANT_TO_ROLE (GRANTED_ROLE, GRANTEE_ROLE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID, PROVISIONED_DATE) VALUES ('" + granted_role + "','" + grantee_role + "','" + source + "',SYSTIMESTAMP,'" + source + "',SYSDATE,'" + dpa_request + "',NULL)"
 
    try:
            cursor.execute(sql)
            #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False
 
    return    
