#
# Modification History:
#   04/08/2020 javier.e.arias@oracle.com  Checks to see if DPA_ROLE_GRANT_TO_SCHEMA has existing data
#
def check_dpa_role_grant_s_has_data(module, msg, cursor, spool, outfile, global_changed, facts, role_name, schema_name):
 
    import cx_Oracle
    import datetime
 
    msg=['']

    sql = "SELECT COUNT(*) FROM OALPROV.DPA_ROLE_GRANT_TO_SCHEMA WHERE ROLE_NAME = '" + role_name + "' AND SCHEMA_NAME = '" + schema_name + "'"

    try:
            cursor.execute(sql)
            result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    if result > 0:
      return True
    else:
      return False
