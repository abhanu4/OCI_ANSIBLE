#
# Modification History:
#   04/30/2020  javier.e.arias@oracle.com  Adding all snippets together in the same file for DPA table modification
#   05/14/2020  javier.e.arias@oracle.com  Adding APT request dates for DPA_DATA_PLATFORM_APPL and DPA_SCHEMA
#


# Snippet to create a record in DPA_DATA_PLATFORM_APPL
def populate_dpa_app(module, msg, cursor, spool, outfile, global_changed, facts, dpa_type, dpa_code, dpa_group_code, dpa_request, source, create_date):
    
    import cx_Oracle
    #import datetime
    
    msg=['']

    if create_date != "":
        if create_date != "SYSDATE" and create_date != "NULL":
            create_date = "TO_DATE('" + create_date + "', 'DD-MON-YYYY HH24:MI:SS')"
    else:
        create_date = "NULL"

    #sql = "INSERT INTO OALPROV.DPA_DATA_PLATFORM_APPL VALUES ('" + dpa_type + "','" + dpa_code + "','" + source + "',SYSTIMESTAMP,'" + source + "'," + create_date + ",'" + dpa_group_code + "','" + dpa_request + "'," + req_date + "," + apprv_date + "," + prov_date + ")"
    sql = "INSERT INTO OALPROV.DPA_DATA_PLATFORM_APPL (DPA_TYPE, DPA_CODE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, DPA_GROUP_CODE, REQUEST_ID) VALUES ('" + dpa_type + "','" + dpa_code + "','" + source + "'," + create_date + ",'" + source + "', SYSTIMESTAMP, '" + dpa_group_code + "','" + dpa_request + "')"                              
    try:
        cursor.execute(sql)
        #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    return


# Snippet to create a record in DPA_SCHEMA
def populate_dpa_schema(module, msg, cursor, spool, outfile, global_changed, facts, schema_name, dpa_type, dpa_code, dpa_request, source, create_date):

    import cx_Oracle
    #import datetime

    msg=['']

    if create_date != "":
        if create_date != "SYSDATE" and create_date != "NULL":
            create_date = "TO_DATE('" + create_date + "', 'DD-MON-YYYY HH24:MI:SS')"
    else:
        create_date = "NULL"

    #sql = "INSERT INTO OALPROV.DPA_SCHEMA VALUES ('" + schema_name + "','" + dpa_type + "','" + dpa_code + "','" + source + "',SYSTIMESTAMP,'" + source + "'," + create_date + ",'" + dpa_request + "'," + req_date + "," + apprv_date + "," + prov_date + ")"
    sql = "INSERT INTO OALPROV.DPA_SCHEMA (SCHEMA_NAME, DPA_TYPE, DPA_CODE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID) VALUES ('" + schema_name + "','" + dpa_type + "','" + dpa_code + "', '" + source + "'," + create_date + ",'" + source + "',SYSTIMESTAMP,'" + dpa_request + "')"

    try:
        cursor.execute(sql)
        #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    return


# Snippet to create a record in DPA_ROLES 
def populate_dpa_roles(module, msg, cursor, spool, outfile, global_changed, facts, role_name, dpa_type, dpa_code, dpa_request, source, create_date, role_type):

    import cx_Oracle
    #import datetime

    msg=['']

    if create_date != "":
        if create_date != "SYSDATE" and create_date != "NULL":
            create_date = "TO_DATE('" + create_date + "', 'DD-MON-YYYY HH24:MI:SS')"
    else:
        create_date = "NULL"
    
    
    #sql = "INSERT INTO OALPROV.DPA_ROLES (ROLE_NAME, DPA_TYPE, DPA_CODE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID, REQUEST_DATE, APPROVED_DATE, PROVISIONED_DATE) VALUES ('" + role_name + "','" + dpa_type + "','" + dpa_code + "','" + source + "',SYSTIMESTAMP,'" + source + "'," + create_date + ",'" + dpa_request + "'," + req_date + "," + apprv_date + "," + prov_date + ")"
    sql = "INSERT INTO OALPROV.DPA_ROLES (ROLE_NAME, DPA_TYPE, DPA_CODE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, ROLE_TYPE, REQUEST_ID) VALUES ('" + role_name + "','" + dpa_type + "','" + dpa_code + "','" + source + "'," + create_date + ",'" + source + "',SYSTIMESTAMP,'" + role_type + "','" + dpa_request + "')" 
    

    try:
        cursor.execute(sql)
        #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    return


# Snippet to create a record in DPA_ROLE_GRANT_TO_ROLE
def populate_dpa_role_grant_role(module, msg, cursor, spool, outfile, global_changed, facts, granted_role, grantee_role, dpa_request, source, create_date):

    import cx_Oracle
    #import datetime

    msg=['']

    if create_date != "":
        if create_date != "SYSDATE" and create_date != "NULL":
            create_date = "TO_DATE('" + create_date + "', 'DD-MON-YYYY HH24:MI:SS')"
    else:
        create_date = "NULL"

    sql = "INSERT INTO OALPROV.DPA_ROLE_GRANT_TO_ROLE (GRANTED_ROLE, GRANTEE_ROLE, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID) VALUES ('" + granted_role + "','" + grantee_role + "','" + source + "'," + create_date + ",'" + source + "',SYSTIMESTAMP,'" + dpa_request + "')"

    try:
        cursor.execute(sql)
        #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    return


# Snippet to create a record in DPA_ROLE_GRANT_TO_SCHEMA
def populate_dpa_role_grant_schema(module, msg, cursor, spool, outfile, global_changed, facts, role_name, schema_name, dpa_request, source, create_date):

    import cx_Oracle
    #import datetime

    msg=['']

    if create_date != "":
        if create_date != "SYSDATE" and create_date != "NULL":
            create_date = "TO_DATE('" + create_date + "', 'DD-MON-YYYY HH24:MI:SS')"
    else:
        create_date = "NULL"

    sql = "INSERT INTO OALPROV.DPA_ROLE_GRANT_TO_SCHEMA (ROLE_NAME, SCHEMA_NAME, CREATED_BY, CREATION_DATE, LAST_UPDATED_BY, LAST_UPDATE_DATE, REQUEST_ID) VALUES ('" + role_name + "','" + schema_name + "','" + source + "'," + create_date + ",'" + source + "',SYSTIMESTAMP,'" + dpa_request + "')"

    try:
        cursor.execute(sql)
        #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    return

# Snippet to update ROLE_TYPE for DPA_ROLES
def update_dpa_role_type_field(module, msg, cursor, spool, outfile, global_changed, facts, role, field, value):

    import cx_Oracle
    
    msg=['']

    
    sql = "UPDATE OALPROV.DPA_ROLES SET " + field + " = '" + value + "' WHERE ROLE_NAME = '" + role + "'"

    
    try:
        cursor.execute(sql)
        #result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = error.message+' sql: ' + sql
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    return




