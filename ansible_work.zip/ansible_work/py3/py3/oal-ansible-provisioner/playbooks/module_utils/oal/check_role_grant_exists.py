#
# Modification History:
#   02/21/2020 todd.grimmett@oracle.com Initial code
#
def check_role_grant_exists(module, msg, cursor, grantee, granted_role, global_changed, facts):
    import cx_Oracle

    msg = ['']

    sql = "select count(*) from dba_role_privs where grantee = upper('"+grantee+"') and granted_role = upper('"+granted_role+"')"

    try:
            cursor.execute(sql)
            result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    if result > 0:
        return True
    else:
        return False
