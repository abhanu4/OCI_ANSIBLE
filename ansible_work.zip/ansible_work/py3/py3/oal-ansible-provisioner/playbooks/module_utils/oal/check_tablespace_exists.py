def check_tablespace_exists(module, msg, cursor, tablespace, global_changed, facts):

    import cx_Oracle

    msg = ['']

    sql = 'select count(*) from dba_tablespaces where tablespace_name = upper(\'%s\')' % tablespace

    try:
            cursor.execute(sql)
            result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    if result > 0:
        return True
    else:
        return False
