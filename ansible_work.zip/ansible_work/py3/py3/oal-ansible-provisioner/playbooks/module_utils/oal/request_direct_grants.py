def request_direct_grants(module, msg, cursor, username, global_changed, facts):
    import cx_Oracle

    msg = ['']

    sql = """
declare
  cursor request_csr is
  select sp.privilege
  from dba_role_privs rp, dba_sys_privs sp
  where rp.grantee = '"""+username+"""'
  and rp.granted_role = sp.grantee
  and sp.privilege IN ('CREATE SYNONYM','CREATE TABLE','CREATE VIEW','CREATE PROCEDURE',
                       'CREATE SEQUENCE','CREATE MATERIALIZED VIEW')
  minus
  select sp.privilege 
  from dba_sys_privs sp
  where sp.grantee = '"""+username+"""';
begin
  for priv in request_csr loop
    sys.oalprov_syspriv_request_pkg.grant_priv
     (p_priv => priv.privilege,
      p_user => '"""+username+"""');
  end loop;
end;
"""

    try:
            cursor.execute(sql)
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    return True
