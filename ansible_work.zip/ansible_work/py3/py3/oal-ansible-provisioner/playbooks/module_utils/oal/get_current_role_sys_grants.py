def get_current_role_sys_grants(module, msg, cursor, role, global_changed, facts):
    import cx_Oracle

    msg = ['']

    curr_role_grants=[]

    sql = "select privilege from dba_sys_privs where grantee = upper(\'%s\') order by privilege "% role

    try:
            cursor.execute(sql)
            result = cursor.fetchall()
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = 'SQL ERROR while fetching existing sys grants for the role - %s sql: %s' % (error.message, sql)
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False
    #if result > 0:
    for item in result:
        #curr_role_grants.append(item[0].lower())
        curr_role_grants.append(item[0].upper())

    return curr_role_grants
