#
# Modification History:
#   09/16/2016 todd.grimmett@oracle.com Since PUBLIC does not actually exist in dba_roles its a special case - Return True if role = 'PUBLIC'
#
def check_role_exists(module, msg, cursor, role, global_changed, facts):
    import cx_Oracle

    msg = ['']

    if role.upper() == 'PUBLIC':
        msg[0] = 'The role (%s) exists' % role
        return True

    sql = 'select count(*) from dba_roles where role = upper(\'%s\')' % role

    try:
            cursor.execute(sql)
            result = cursor.fetchone()[0]
    except cx_Oracle.DatabaseError, exc:
            error, = exc.args
            msg[0] = error.message+' sql: ' + sql
            module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
            return False

    if result > 0:
        msg[0] = 'The role (%s) exists' % role
        return True
    else:
        msg[0] = 'The role (%s) does not exist' % role
        return False
