def execute_sql(module, cursor, sql, spool, outfile, global_changed, facts):
    import cx_Oracle

    msg = ['']

    try:
        cursor.execute(sql)
    except cx_Oracle.DatabaseError, exc:
        error, = exc.args
        msg[0] = 'ERROR: Executing sql - %s sql: %s' % (error.message, sql)
        module.fail_json(msg=msg[0], changed=global_changed, facts=facts)
        return False

    if spool:
        pwd_index = -1
        words = []
        words = sql.split()
        word_count = len(words)
        for i in range(len(words)):
           if words[i].upper() == 'IDENTIFIED':
               #if words.upper[i+1] == 'BY':
               if words[i+1].upper() == 'BY':
                  pwd_index = i + 2
           if i == pwd_index:
               the_password = words[i]
        if pwd_index == -1:
            outfile.write(sql+';\n')
        else:
            suppress_pwd_sql = sql.replace(the_password, '"********"')
            outfile.write(suppress_pwd_sql+';\n')
        #outfile.write('Word count = '+str(word_count)+'\n')

    return True
