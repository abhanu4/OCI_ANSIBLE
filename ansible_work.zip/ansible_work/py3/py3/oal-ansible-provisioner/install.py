#!/usr/bin/env python
'''
# Author......:  T.Grimmett
# Status......:  Work In Progress
# Status Date :  07/16/2019
# Version.....:  1.0
# Purpose:
#  Copy the module, playbooks and binaries from the project directory to /etc/ansible
#  It also configures /etc/ansible/ansible.cfg to use "library=/etc/ansible/library"
# Notes:
# 1) if the /etc/ansible/<dir> directories do not exist, this script will create them.
#
# Revision History:
#  09/11/2018 TJG Initial Code
#  07/16/2019 TJG Add branch support
#  08/26/2019 TJG Add sql_custom_oalprov support
'''
 
from __future__ import print_function
import argparse
import os.path
import shutil
import sys
import datetime
import fileinput

excludeList = ["local_test_suite.yml","run_test_suite.sh","oracle_oal_reset_database"]
if ("--withTest" in sys.argv):
    excludeList = []

 
#####################################################
#
# Function to copy files from one dir to another and provide a message
#
#####################################################
def copy_files(files, src_dir, dest_dir):
    if not os.path.isdir(src_dir):
        print("  Source directory {0} does not exist, nothing to copy".format(src_dir))
    else:
        print ("  Copying files from {0} to {1}".format(src_dir,dest_dir))
        if files is None:
            files = os.listdir(src_dir)
        elif type(files) is not list:
            files = [files]
        for file in files:
            if (file not in excludeList and
                not file.endswith(".swp")):
                src_file_path = os.path.join(src_dir, file)
                if os.path.isfile(src_file_path):
                    dest_file_path = os.path.join(dest_dir, file)
                    if os.path.exists(dest_file_path):
                        print("    Overwriting file {0} with {1}".format(dest_file_path,src_file_path))
                    else:
                        print("    Copying file {0} from {1}".format(dest_file_path,src_file_path))
                    #shutil.copy(src_file_path, dest_file_path)
                    shutil.copy2(src_file_path, dest_file_path)
                else:
                    print("    Skipping directory {0}".format(src_file_path))
            else:
                print("    Excluded file {0}".format(file))
 
#####################################################
#
# Function to chmod files in a directory
#
#####################################################
def chmod_files(files, directory):
    if os.path.isdir(directory):
        if type(files) is not list:
            files = [files]
        for file in files:
            if (file not in excludeList):
                if file[-3:] == '.sh' or file[-3:] == '.py':
                    file_path = os.path.join(directory, file)
                    mode = 0o774
                    os.chmod(file_path, mode)

#####################################################
#
# Function to create a directory
#
#####################################################
def create_dir(dirpath):
    if not os.path.isdir(dirpath):
        print("  Creating directory: {0}".format(dirpath))
        try:
            os.mkdir(dirpath, 0o750)
        except OSError as ex:
            print("  ERROR: mkdir {0} failed with {1}".format(dirpath, ex))
            sys.exit(1)
        else:
            print("  Succesfully created directory {0}.".format(dirpath))
    else:
        print("  Directory already exists: {0}".format(dirpath))
 
#####################################################
#
# Function to copy a directory tree
#
#####################################################
def copy_tree(src, dst, symlinks=False, ignore=None):
    if not os.path.exists(src):
        print("  Source directory {0} does not exist, nothing to copy".format(src))
    else:
        if not os.path.exists(dst):
            os.makedirs(dst)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dst, item)
            if os.path.isdir(s):
                copy_tree(s, d, symlinks, ignore)
            elif item.endswith(".swp"):
                print("Skipping swap file")
            else:
                #if not os.path.exists(d) or os.stat(s).st_mtime - os.stat(d).st_mtime > 1:
                #    shutil.copy2(s, d)
                if os.path.exists(d):
                    print("    Overwriting file {0} with {1}".format(d,s))
                else:
                     print("    Copying file {0} from {1}".format(d,s))
                shutil.copy2(s, d)
 
 
#####################################################
#
# Function to parse input parameters
#
#####################################################
def parse_cli_args():
    parser = argparse.ArgumentParser(description='Script to install OAL Ansible Provisioning components')
    parser.add_argument('--env',
        action='store',
        required=True,
        help='Which /etc/ansible/envs/<env> to copy to')
    #parser.add_argument('--branch',
    #    action='store',
    #    required=True,
    #    help='Which code branch to install from')
    return parser.parse_args()
 
#####################################################
#
# End of function parse_cli_args()
#
#####################################################
 
def main():
    begin_time = datetime.datetime.now()
    print ("\n")
    print ("install.py starts at "+str(begin_time))
    print ("\n")
 
    args = parse_cli_args()

    if args.env:
        print ("  Target environment: "+args.env)
 
    #   ansible_base = os.path.dirname(os.path.abspath(os.path.realpath(ansible.__file__)))
    #   The above statement picks up: Ansible path: /usr/lib/python2.7/site-packages/ansible 
    #   I've seen some installations that put their modules directly into ansible like above. We won't do that.
    #   We will install into /etc/ansible/envs/<env>library and set up environment variables to point at it.
 
    #
    # Set up base for our ansible base
    #
    ansible_base = '/etc/ansible'
    create_dir(ansible_base)

    current_path = os.path.dirname(os.path.abspath(os.path.realpath(__file__)))
    print("  Current path: {0}".format(current_path))

    #
    # Set up 'envs' directory , if it doesn't exist create it
    #
    ansible_envs = '/etc/ansible/envs'
    create_dir(ansible_envs)
    #
    # Set up this <env> directory , if it doesn't exist create it
    #
    ansible_envs_env = '/etc/ansible/envs/'+args.env
    create_dir(ansible_envs_env)

    #
    # Set up /etc/ansible/envs/<env>/library
    #
    ansible_library_path = os.path.join(ansible_base, 'envs', args.env, 'library')
    print("  Ansible library path: {0}".format(ansible_library_path))
    create_dir(ansible_library_path)
    #
    #  Copy our modules to library
    # 
    current_library_path = os.path.join(current_path, 'library')
    copy_files(None, current_library_path, ansible_library_path)

    #
    # Set up /etc/ansible/envs/<env>/playbooks
    #
    ansible_playbooks_path = os.path.join(ansible_base, 'envs', args.env, 'playbooks')
    create_dir(ansible_playbooks_path)
    #
    #  Copy our playbooks to /etc/ansible/envs/<env>/playbooks
    # 
    current_playbooks_path = os.path.join(current_path, 'playbooks')
    copy_files(None, current_playbooks_path, ansible_playbooks_path)

    #
    # Set up /etc/ansible/envs/<env>/playbooks/module_utils
    #
    ansible_module_utils_path = os.path.join(ansible_playbooks_path, 'module_utils')
    create_dir(ansible_module_utils_path)

    #
    # Set up /etc/ansible/envs/<env>/playbooks/module_utils/oal
    #
    ansible_module_utils_oal_path = os.path.join(ansible_module_utils_path, 'oal')
    create_dir(ansible_module_utils_oal_path)
    #
    #  Copy our oal python package to /etc/ansible/envs/<env>/playbooks/module_utils/oal
    # 
    current_module_utils_oal_path = os.path.join(current_path, 'playbooks', 'module_utils', 'oal')
    copy_files(None, current_module_utils_oal_path, ansible_module_utils_oal_path)

    #
    # Set up /etc/ansible/envs/<env>/bin
    #
    ansible_bin_path = os.path.join(ansible_base, 'envs', args.env, 'bin')
    create_dir(ansible_bin_path)
    #
    #  Copy our executables to /etc/ansible/envs/<env>/bin
    # 
    current_bin_path = os.path.join(current_path, 'bin')
    #copy_tree(current_bin_path, ansible_bin_path)
    copy_files(None, current_bin_path, ansible_bin_path)
    #
    # Make sure executables have 774
    #
    chmod_files(os.listdir(current_bin_path), ansible_bin_path)

    #
    # Set up /etc/ansible/bin/utilities
    #
    ansible_bin_util_path = os.path.join(ansible_bin_path, 'utilities')
    create_dir(ansible_bin_util_path)
    #
    #  Copy our executables to /etc/ansible/envs/<env>/bin/utilities
    # 
    current_bin_util_path = os.path.join(current_path, 'bin', 'utilities')
    copy_files(None, current_bin_util_path, ansible_bin_util_path)
    #
    # Make sure executables have 774
    #
    chmod_files(os.listdir(current_bin_util_path), ansible_bin_util_path)

    #
    # Set up /etc/ansible/envs/<env>/sql
    #
    ansible_sql_path = os.path.join(ansible_base, 'envs', args.env, 'sql')
    create_dir(ansible_sql_path)
    #
    #  Copy our sql files to /etc/ansible/envs/<env>/sql
    # 
    current_sql_path = os.path.join(current_path, 'sql')
    copy_files(None, current_sql_path, ansible_sql_path)
    #copy_tree(current_sql_path, ansible_sql_path)

    #
    # Set up /etc/ansible/envs/<env>/sql_custom_oalprov
    #
    ansible_sql_custom_oalprov_path = os.path.join(ansible_base, 'envs', args.env, 'sql_custom_oalprov')
    create_dir(ansible_sql_custom_oalprov_path)
    #
    #  Copy the common custom sql files to /etc/ansible/envs/<env>/sql_custom_oalprov
    # 
    current_common_sql_custom_oalprov_path = os.path.join(current_path, 'envs', 'common','sql_custom_oalprov')
    copy_files(None, current_common_sql_custom_oalprov_path, ansible_sql_custom_oalprov_path)

    #
    # Set up /etc/ansible/envs/<env>/metrics
    #
    ansible_metrics_path = os.path.join(ansible_base, 'envs', args.env, 'metrics')
    create_dir(ansible_metrics_path)

    #
    # Set up /etc/ansible/commits
    #
    # MAYBE: NOT SURE I WANT commits AT ENV level yet, if ever
    # Set up /etc/ansible/envs/<env>/commits
    #ansible_commits_path = os.path.join(ansible_base, 'envs', args.env, 'commits')

    ansible_commits_path = os.path.join(ansible_base, 'commits')
    create_dir(ansible_commits_path)
    #
    # See if /etc/ansible/envs/adw exist, if not create it
    #
    # FUTURE
    #tgt_envs_adw = os.path.join(ansible_envs, 'adw')
    #create_dir(tgt_envs_adw)
    #
    # See if /etc/ansible/envs/adw/vars_sys exist, if not create it
    #
    #tgt_envs_adw_vars_sys = os.path.join(tgt_envs_adw, 'vars_sys')
    #create_dir(tgt_envs_adw_vars_sys)
    #print("  Target envs adw vars_sys: {0}".format(tgt_envs_adw_vars_sys))
    #
    #  Copy our "adw" vars_sys files to /etc/ansible/envs/adw/vars_sys
    # 
    #current_vars_adw_vars_sys_path = os.path.join(current_path, 'envs', 'adw', 'vars_sys')
    #copy_files(None, current_vars_adw_vars_sys_path, tgt_envs_adw_vars_sys)

    #
    # See if /etc/ansible/envs/common exist, if not create it
    #
    tgt_envs_common = os.path.join(ansible_envs, 'common')
    create_dir(tgt_envs_common)
    #
    # See if /etc/ansible/envs/common/vars_app exist, if not create it
    #
    tgt_envs_common_vars_app = os.path.join(tgt_envs_common, 'vars_app')
    create_dir(tgt_envs_common_vars_app)
    print("  Target envs common vars_app: {0}".format(tgt_envs_common_vars_app))
    #
    #  Copy our "common" vars_app files to /etc/ansible/envs/common/vars_app
    # 
    current_vars_common_vars_app_path = os.path.join(current_path, 'envs', 'common', 'vars_app')
    copy_files(None, current_vars_common_vars_app_path, tgt_envs_common_vars_app)
 
    #
    # See if /etc/ansible/envs/common/vars_sys exist, if not create it
    #
    tgt_envs_common_vars_sys = os.path.join(tgt_envs_common, 'vars_sys')
    create_dir(tgt_envs_common_vars_sys)
    print("  Target envs common vars_sys: {0}".format(tgt_envs_common_vars_sys))
    #
    #  Copy our "common" vars_sys files to /etc/ansible/envs/common/vars_sys
    # 
    current_vars_common_vars_sys_path = os.path.join(current_path, 'envs', 'common', 'vars_sys')
    copy_files(None, current_vars_common_vars_sys_path, tgt_envs_common_vars_sys)
 
    #
    # See if /etc/ansible/envs/common/bin exist, if not create it
    #
    tgt_envs_common_bin = os.path.join(tgt_envs_common, 'bin')
    create_dir(tgt_envs_common_bin)
    print("  Target envs common bin: {0}".format(tgt_envs_common_bin))
    #
    #  Copy our "common" bin files to /etc/ansible/envs/common/bin
    # 
    current_vars_common_bin_path = os.path.join(current_path, 'envs', 'common', 'bin')
    copy_files(None, current_vars_common_bin_path, tgt_envs_common_bin)
 
    print("\n")
    print("  OAL ansible provisioning modules installed successfully.")
 
    end_time = datetime.datetime.now()
    print ("\n")
    print ("install.py ends at "+str(end_time))
    print ("\n")
 
if __name__ == '__main__':
    main()
